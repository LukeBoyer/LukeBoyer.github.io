from data import *
from hypothesis import *
from cementData import *
from sklearn.linear_model import LinearRegression

data = CementData().getData()

l = len(data[0])//2

trainData = [data[0][:l], data[1][:l]]
testData = [data[0][l:], data[1][l:]]

reg1 = LinearRegression().fit(trainData[0], trainData[1])
print(reg1.score(testData[0], testData[1]))
print(reg1.coef_)
print(reg1.intercept_)

