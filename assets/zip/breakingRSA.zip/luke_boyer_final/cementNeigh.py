from sklearn.neighbors import KNeighborsRegressor
from cementData import *

data = CementData().getData()

l = len(data[0])//2

trainData = [data[0][:l], data[1][:l]]
testData = [data[0][l:], data[1][l:]]

neigh1 = KNeighborsRegressor(n_neighbors=5)
neigh1.fit(trainData[0], trainData[1])
print('k=5', neigh1.score(testData[0], testData[1]))

neigh2 = KNeighborsRegressor(n_neighbors=10)
neigh2.fit(trainData[0], trainData[1])
print('k=10', neigh2.score(testData[0], testData[1]))


