from primes import *
import math

def getResidueHypoth(*bases):

	def hyptothFunc(n):
		return [n % base for base in bases] #can return lamba

	return hyptothFunc

def getMiddleHypoth(m):
	primes = Primes().getPrimes()
	def middleHypoth(n):
		sqrtLoc = getInsertIndex(math.sqrt(n), primes)
		leftPrimes = primes[:sqrtLoc]
		rightPrimes = primes[sqrtLoc:]
		res = []
		for _ in range(m):
			minStack = (leftPrimes, -1) if leftPrimes[-1] < rightPrimes[0] else (rightPrimes, 0)
			base = minStack[0].pop(minStack[1])
			res.append((n%base)/math.sqrt(n))
		return res
	return middleHypoth

def getInsertIndex(i, ls):

	l = 0
	r = len(ls) - 1

	while l <= r:
 
		mid = l + (r - l) // 2
 
		# If x is greater, ignore left half
		if ls[mid] < i:
			l = mid + 1
 
		# If x is smaller, ignore right half
		else:
			r = mid - 1
	 
	# If we reach here, then the element
	# was not present
	return l




