from primes import *
import math

class Data:

	def __init__(self, hypoth):

		self.hypoth = hypoth

	def __call__(self, primeBound, numSamples):
		primes = Primes()(primeBound, numSamples)
		resX = []
		resY = []
		for p in primes:
			resY.append(self.getBoyerValue(*p))
			resX.append(self.hypoth(p[2]))
		return (resX, resY)
		
	def getBoyerValue(self, p, q, n):
		return min(p, q)/math.sqrt(n)

	@staticmethod
	def mod3And7Att(n):
		return [n%3, n%7]

	@staticmethod
	def mod35711(n):
		return [n%3, n%7, n%5, n%11]

	@staticmethod
	def nAndMod3(n):
		return [n]