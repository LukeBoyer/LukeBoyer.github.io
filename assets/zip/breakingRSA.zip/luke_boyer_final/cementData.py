import openpyxl
import random

class CementData:

	def __init__(self):

		wb = openpyxl.load_workbook("Concrete_Data.xlsx")
		ws = wb.active
		self.data = []
		self.target = []
		rows = list(ws.iter_rows(values_only=True))
		rows.pop(0)
		random.shuffle(rows)
		for row in rows:
			self.data.append(row[:-1])
			self.target.append(row[-1])

	def getData(self):
		return [self.data, self.target]


	