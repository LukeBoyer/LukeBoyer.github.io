import csv
import random

class Primes:

	def __init__(self):
		with open('p3.csv', newline='') as csvfile:
			spamreader = csv.reader(csvfile, delimiter=' ', quotechar='|')
			self.primes = [int(row[1].strip(','))for row in spamreader]
	
	def __call__(self, numPrimes, numInts):

		"""returns numInts possible valus for n and their two prime factors"""

		ps = self.primes[:numPrimes]
		def getN():
			p = random.choice(ps)
			q = random.choice(ps)
			while p == q:
				q = random.choice(ps)
			return (p, q, p * q)
		return [getN() for _ in range(numInts)]

	def getPrimes(self):
		return self.primes.copy()








