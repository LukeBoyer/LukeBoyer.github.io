from data import *
from hypothesis import *

PRIME_BOUND = 100000
NUM_SAMPLES = 1000

h1 = getResidueHypoth(3)
h2 = getResidueHypoth(3, 5, 7)
h3 = getMiddleHypoth(20)
h4 = getMiddleHypoth(50)
h5 = getMiddleHypoth(100)

data1 = Data(h1)(PRIME_BOUND, NUM_SAMPLES)
data2 = Data(h2)(PRIME_BOUND, NUM_SAMPLES)
data3 = Data(h3)(PRIME_BOUND, NUM_SAMPLES)
data4 = Data(h4)(PRIME_BOUND, NUM_SAMPLES)
data5 = Data(h5)(PRIME_BOUND, NUM_SAMPLES)

from sklearn.linear_model import LinearRegression

reg1 = LinearRegression().fit(data1[0], data1[1])
print(reg1.score(data1[0], data1[1]))

reg2 = LinearRegression().fit(data2[0], data2[1])
print(reg2.score(data2[0], data2[1]))

reg3 = LinearRegression().fit(data3[0], data3[1])
print(reg3.score(data3[0], data3[1]))

reg4 = LinearRegression().fit(data4[0], data4[1])
print(reg4.score(data4[0], data4[1]))

reg5 = LinearRegression().fit(data5[0], data5[1])
print(reg5.score(data5[0], data5[1]))