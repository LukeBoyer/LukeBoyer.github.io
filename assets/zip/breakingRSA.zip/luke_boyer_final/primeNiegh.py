from sklearn.neighbors import KNeighborsRegressor
from data import *
from hypothesis import *

PRIME_BOUND = 100000
NUM_SAMPLES = 1000

h1 = getResidueHypoth(3)
h2 = getResidueHypoth(3, 5, 7)
h3 = getMiddleHypoth(50)

data1 = Data(h1)(PRIME_BOUND, NUM_SAMPLES)
testData1 = Data(h1)(PRIME_BOUND, NUM_SAMPLES)
data2 = Data(h2)(PRIME_BOUND, NUM_SAMPLES)
testData2 = Data(h2)(PRIME_BOUND, NUM_SAMPLES)
data3 = Data(h3)(PRIME_BOUND, NUM_SAMPLES)
testData3 = Data(h3)(PRIME_BOUND, NUM_SAMPLES)

neigh1 = KNeighborsRegressor(n_neighbors=5)
neigh1.fit(data1[0], data1[1])
print('h1', neigh1.score(testData1[0], testData1[1]))
neigh2 = KNeighborsRegressor(n_neighbors=5)
neigh2.fit(data2[0], data2[1])
print('h2', neigh2.score(testData2[0], testData2[1]))
neigh3 = KNeighborsRegressor(n_neighbors=50)
neigh3.fit(data3[0], data3[1])
print('h3', neigh3.score(testData3[0], testData3[1]))

